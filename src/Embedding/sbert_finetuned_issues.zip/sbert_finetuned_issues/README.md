---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:121171
- loss:MultipleNegativesRankingLoss
base_model: sentence-transformers/all-MiniLM-L6-v2
widget:
- source_sentence: 'Releasev1<NUMBER> Test Value Attribution Gatewaymt [SEP] edge
    services satellite deployed QA cluster point rclone staging gatewaymt create fresh
    bucket > new bucket rcloen value attribution satellite DB [SEP] '
  sentences:
  - 'Resolve Remove network disconnect warning merged [SEP] GitLab <MENTION> Merges
    <NUMBER>removenetworkdisconnectwarning > dev Closes <ISSUE_REF> [SEP]    '
  - 'MetaMask calculate correct transaction nonce [SEP] MetaMask calculate correct
    transaction nonce multiple transactions issued well known eth_getTransactionCount
    return correct number pending transactions<LINK> wondering guys Could really beneficial
    community learn [SEP]    '
  - 'Releasev1<NUMBER> Test Value Attribution Gatewaymt [SEP] edge services satellite
    deployed QA cluster point rclone staging gatewaymt create fresh bucket > new bucket
    rcloen value attribution satellite DB [SEP] '
- source_sentence: 'Best route calculation upgrade [SEP] best swap calculation user
    dont yet take account contracts already approved extra approval call could alter
    order favourable swaps [SEP]  '
  sentences:
  - ' [SEP] Describe bug Whenever using old MM versions new browser versions trying
    open wallet leads MM loading indefinetly displaying blank screen Notice rare case
    users automatic extension updates default dont uploading build local encounter
    issue Expected behavior Handle cases gracefully giving hint users ScreenshotsRecordings
    <LINK> Steps reproduce <NUMBER> Download MM version <NUMBER>XX <NUMBER> Upload
    lates version chrome <NUMBER> See blank screen Error messages log output response
    Version <<NUMBER>XXXX new versions browser Build type None Browser Chrome Operating
    system Linux Hardware wallet response Additional context response Severity response
    [SEP] Bug Browser Incompatibilities Using old MetaMask wallets new browser versions
    cause MM load indefinetly display blank screen'
  - 'best swap calculation user dont yet take account contracts already approved extra
    approval call could alter order favourable swaps [SEP] Best route calculation
    upgrade [SEP]  '
  - '    [SEP] Rationale feature exist Obtaining latest block number common requirement
    current http grpc seem implemented getnowblock provides much redundant information
    Implementation ideas regarding implementation feature orgtroncoreservicesjsonrpcTronJsonRpcImplgetLatestBlockNum<LINK>
    [SEP] Add APIs like eth_blockNumber grpc http'
- source_sentence: 'Transaction list filter blockchain submitted [SEP]  [SEP] '
  sentences:
  - '           [SEP] check eth address valid [SEP] havent found api check ethaddress
    valid func like bitcoincore bool ValidateAddressaddress'
  - ' [SEP] flaky tests <CODE_BLOCK> [SEP] <LINK> Scenario response Design response
    Technical Details response Threat Modeling Framework response Acceptance Criteria
    response Stakeholder review needed work gets merged Engineering needed cases Design
    Product QA automation tests required pass merging PRs changes covered automation
    tests please review QA needed beyond automation tests Security Legal Marketing
    Management please specify please specify References response'
  - ' [SEP]  [SEP] Transaction list filter blockchain submitted'
- source_sentence: 'Suggestions documentation improvements [SEP] Context someone prior
    web dev experience cursory knowledge crypto reading documentation ran following
    issues alongside Ive added suggestions could improved beginner <NUMBER> readme
    starts explaining onchain program web3 application unclear web3 application Suggestion
    Add detail web3 application Eg web3 application setup interact onchain program
    currently supports XYZ <NUMBER> goes architecture deep dive useful detailed however
    reading unclear next steps need go Solana docs write code interact contracts Ultimately
    turned didnt need read yet order set basic auction since web app lot functionality
    implemented already Suggestion Move readme understanding needed attempting implement
    functionality beyond whats supported existing web3 application Suggestion Preface
    section Prerequisite knowledge acronyms terms make difficult beginner Solana intended
    audience eg Intended developers want XYZ outcomes expected reading documentation
    eg learn XYZ <NUMBER> installation guide straight forward unclear exactly web
    app installing ie get Suggestion helped <NUMBER> would also add web app allows
    create store Suggestion <CODEBLOCK> <CODEBLOCK> appear thing cleaned <NUMBER>
    installing initializing store everything worked creating auction kept failing
    Eventually spending SOL realized <CODEBLOCK> directory read <CODEBLOCK> Suggestion
    make docs prominent include section linking readme Suggestion Mention wallet may
    connected <CODE_BLOCK> using real funds even interacting locally app <NUMBER>
    ended skimming seemed replicating already done initialize store button realized
    needed update <CODE_BLOCK> crucial make sure create auction process fail Suggestion
    Update docs create store process web3 app indicate important step <NUMBER> Deployment
    instructions worked perfectly without issues Suggestion suggestion would promote
    visibility doc [SEP] '
  sentences:
  - 'Context someone prior web dev experience cursory knowledge crypto reading documentation
    ran following issues alongside Ive added suggestions could improved beginner <NUMBER>
    readme starts explaining onchain program web3 application unclear web3 application
    Suggestion Add detail web3 application Eg web3 application setup interact onchain
    program currently supports XYZ <NUMBER> goes architecture deep dive useful detailed
    however reading unclear next steps need go Solana docs write code interact contracts
    Ultimately turned didnt need read yet order set basic auction since web app lot
    functionality implemented already Suggestion Move readme understanding needed
    attempting implement functionality beyond whats supported existing web3 application
    Suggestion Preface section Prerequisite knowledge acronyms terms make difficult
    beginner Solana intended audience eg Intended developers want XYZ outcomes expected
    reading documentation eg learn XYZ <NUMBER> installation guide straight forward
    unclear exactly web app installing ie get Suggestion helped <NUMBER> would also
    add web app allows create store Suggestion <CODEBLOCK> <CODEBLOCK> appear thing
    cleaned <NUMBER> installing initializing store everything worked creating auction
    kept failing Eventually spending SOL realized <CODEBLOCK> directory read <CODEBLOCK>
    Suggestion make docs prominent include section linking readme Suggestion Mention
    wallet may connected <CODE_BLOCK> using real funds even interacting locally app
    <NUMBER> ended skimming seemed replicating already done initialize store button
    realized needed update <CODE_BLOCK> crucial make sure create auction process fail
    Suggestion Update docs create store process web3 app indicate important step <NUMBER>
    Deployment instructions worked perfectly without issues Suggestion suggestion
    would promote visibility doc [SEP] Suggestions documentation improvements [SEP] '
  - '<CODEBLOCK> uses image <CODEBLOCK> running local network key generation fails
    script tries invoke <CODEBLOCK> image contains <CODEBLOCK> [SEP] testnetkeyspy
    outdated daemon image [SEP] '
  - 'Refactor incrementalsecurityspecjs follow pattern metamaskextensionteste2etests
    [SEP] part <ISSUE_REF> todo item incrementalsecurityspecjs [SEP] '
- source_sentence: 'help [SEP] System information Geth version <CODE_BLOCK> OS Version
    WindowsLinuxOSX Commit hash <CODE_BLOCK> Expected behaviour Actual behaviour Steps
    reproduce behaviour Backtrace <CODE_BLOCK> Im coder Etherscanio says contract
    worth money cant access Pls help pls email 11001100xn<MENTION>com [SEP]  '
  sentences:
  - ' [SEP] x protors fix <LINK> x scruntime update dependency protors x scruntime
    merge <LINK> x scruntime fix <LINK> x scruntime add <LINK> x scruntime cargo update
    x add GRPC stream filters <LINK> x massa update dependency protors x massa update
    dependency massascruntime x massa make sure <LINK> works x massa finish <LINK>
    x massa fix <LINK> x massa fix <LINK> x massa fix <LINK> x massa fix <LINK> x
    massa <LINK> x massa <LINK> x massa cargo update <ISSUE_REF> x massa test SC deployment
    call massaweb3 massastation <ISSUE_REF> [SEP] TESTNET <NUMBER> CHECKLIST'
  - Write SRP page [SEP]  [SEP] tip Write store multiple secret places tip twice Remove
    one instance Store bank vault redundant since also say Store safedeposit box remove
    keep Save password manager decided thats actually safe tip way hide SRP revealing
    provide option requires design input cc <MENTION>
  - 'help [SEP] System information Geth version <CODE_BLOCK> OS Version WindowsLinuxOSX
    Commit hash <CODE_BLOCK> Expected behaviour Actual behaviour Steps reproduce behaviour
    Backtrace <CODE_BLOCK> Im coder Etherscanio says contract worth money cant access
    Pls help pls email 11001100xn<MENTION>com [SEP]  '
pipeline_tag: sentence-similarity
library_name: sentence-transformers
---

# SentenceTransformer based on sentence-transformers/all-MiniLM-L6-v2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2). It maps sentences & paragraphs to a 384-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, text classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [sentence-transformers/all-MiniLM-L6-v2](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) <!-- at revision fa97f6e7cb1a59073dff9e6b13e2715cf7475ac9 -->
- **Maximum Sequence Length:** 256 tokens
- **Output Dimensionality:** 384 dimensions
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 256, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 384, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
  (2): Normalize()
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'help [SEP] System information Geth version <CODE_BLOCK> OS Version WindowsLinuxOSX Commit hash <CODE_BLOCK> Expected behaviour Actual behaviour Steps reproduce behaviour Backtrace <CODE_BLOCK> Im coder Etherscanio says contract worth money cant access Pls help pls email 11001100xn<MENTION>com [SEP]  ',
    'help [SEP] System information Geth version <CODE_BLOCK> OS Version WindowsLinuxOSX Commit hash <CODE_BLOCK> Expected behaviour Actual behaviour Steps reproduce behaviour Backtrace <CODE_BLOCK> Im coder Etherscanio says contract worth money cant access Pls help pls email 11001100xn<MENTION>com [SEP]  ',
    ' [SEP] x protors fix <LINK> x scruntime update dependency protors x scruntime merge <LINK> x scruntime fix <LINK> x scruntime add <LINK> x scruntime cargo update x add GRPC stream filters <LINK> x massa update dependency protors x massa update dependency massascruntime x massa make sure <LINK> works x massa finish <LINK> x massa fix <LINK> x massa fix <LINK> x massa fix <LINK> x massa fix <LINK> x massa <LINK> x massa <LINK> x massa cargo update <ISSUE_REF> x massa test SC deployment call massaweb3 massastation <ISSUE_REF> [SEP] TESTNET <NUMBER> CHECKLIST',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 384]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset


* Size: 121,171 training samples
* Columns: <code>sentence_0</code> and <code>sentence_1</code>
* Approximate statistics based on the first 1000 samples:
  |         | sentence_0                                                                         | sentence_1                                                                         |
  |:--------|:-----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
  | type    | string                                                                             | string                                                                             |
  | details | <ul><li>min: 4 tokens</li><li>mean: 85.35 tokens</li><li>max: 256 tokens</li></ul> | <ul><li>min: 4 tokens</li><li>mean: 85.35 tokens</li><li>max: 256 tokens</li></ul> |
* Samples:
  | sentence_0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | sentence_1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
  |:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
  | <code>Mina Daemon Crash Logs Linux Distro Ubuntu <NUMBER><NUMBER> DigitalOcean c<NUMBER>16gib [SEP] crashsummaryjson_ OS_typeUnix Release<NUMBER><NUMBER><NUMBER><NUMBER>generic Machinex86_64 Sys_nameLinux Exception commit_ida42bdeef6b0c15ee34616e4df76c882b0c5c7c2a sexp monitormlError Failure IO error lock file rootminaconfigtrustLOCK Resource temporarily unavailable Raised file stdlibml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibrocksdbdatabaseml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibtrustsystempeertrustml line <NUMBER> characters <NUMBER><NUMBER> Called file srcappclisrcminaml line <NUMBER> characters <NUMBER><NUMBER> Called file srcdeferred0ml line <NUMBER> characters <NUMBER><NUMBER> Called file srcjob_queueml inlined line <NUMBER> characters <NUMBER><NUMBER> Called file srcjob_queueml line <NUMBER> characters <NUMBER><NUMBER> Caught monitor coda backtrace Raised file stdlibml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibrocksdbdatabas...</code> | <code> [SEP] Mina Daemon Crash Logs Linux Distro Ubuntu <NUMBER><NUMBER> DigitalOcean c<NUMBER>16gib [SEP] crashsummaryjson_ OS_typeUnix Release<NUMBER><NUMBER><NUMBER><NUMBER>generic Machinex86_64 Sys_nameLinux Exception commit_ida42bdeef6b0c15ee34616e4df76c882b0c5c7c2a sexp monitormlError Failure IO error lock file rootminaconfigtrustLOCK Resource temporarily unavailable Raised file stdlibml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibrocksdbdatabaseml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibtrustsystempeertrustml line <NUMBER> characters <NUMBER><NUMBER> Called file srcappclisrcminaml line <NUMBER> characters <NUMBER><NUMBER> Called file srcdeferred0ml line <NUMBER> characters <NUMBER><NUMBER> Called file srcjob_queueml inlined line <NUMBER> characters <NUMBER><NUMBER> Called file srcjob_queueml line <NUMBER> characters <NUMBER><NUMBER> Caught monitor coda backtrace Raised file stdlibml line <NUMBER> characters <NUMBER><NUMBER> Called file srclibrocksdb...</code> |
  | <code>chia VPN Express Synced Farmed Rewards chia快速爆快同步加速器 [SEP] <LINK> [SEP] </code>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | <code><LINK> [SEP] chia VPN Express Synced Farmed Rewards chia快速爆快同步加速器 [SEP] </code>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
  | <code>Cannot find transactions account [SEP] Using latest master cannot find transactions inita something wrong eosioc p <CODE> get info server_version 8d245066 headblocknum <CODE> lastirreversibleblock_num <CODE> headblockid 000023c94320e1314fa7e4d8761f497c11151a3400be7747ec84cb13190150e8 headblocktime <CODE><NUMBER>01T02<NUMBER><NUMBER> headblockproducer inito recent_slots <CODE> participation_rate <NUMBER><CODE> eosioc p <CODE> get transactions inita 2417287ms thread<NUMBER> maincpp<CODE> main Failed error Assert Exception <NUMBER> status_code <NUMBER> Error code <NUMBER> code<NUMBER>messageNot FounddetailsUnknown Endpoint [SEP]  </code>                                                                                                                                                                                                                                                                                                                                                                                 | <code>  [SEP] Using latest master cannot find transactions inita something wrong eosioc p <CODE> get info server_version 8d245066 headblocknum <CODE> lastirreversibleblock_num <CODE> headblockid 000023c94320e1314fa7e4d8761f497c11151a3400be7747ec84cb13190150e8 headblocktime <CODE><NUMBER>01T02<NUMBER><NUMBER> headblockproducer inito recent_slots <CODE> participation_rate <NUMBER><CODE> eosioc p <CODE> get transactions inita 2417287ms thread<NUMBER> maincpp<CODE> main Failed error Assert Exception <NUMBER> status_code <NUMBER> Error code <NUMBER> code<NUMBER>messageNot FounddetailsUnknown Endpoint [SEP] Cannot find transactions account</code>                                                                                                                                                                                                                                                                                                                                                                                 |
* Loss: [<code>MultipleNegativesRankingLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#multiplenegativesrankingloss) with these parameters:
  ```json
  {
      "scale": 20.0,
      "similarity_fct": "cos_sim"
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `num_train_epochs`: 4
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: no
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `torch_empty_cache_steps`: None
- `learning_rate`: 5e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1
- `num_train_epochs`: 4
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.0
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: False
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: False
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `include_for_metrics`: []
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `dispatch_batches`: None
- `split_batches`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `use_liger_kernel`: False
- `eval_use_gather_object`: False
- `average_tokens_across_devices`: False
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin

</details>

### Training Logs
| Epoch  | Step  | Training Loss |
|:------:|:-----:|:-------------:|
| 0.0660 | 500   | 0.0004        |
| 0.1320 | 1000  | 0.0           |
| 0.1980 | 1500  | 0.0           |
| 0.2641 | 2000  | 0.0           |
| 0.3301 | 2500  | 0.0           |
| 0.3961 | 3000  | 0.0001        |
| 0.4621 | 3500  | 0.0001        |
| 0.5281 | 4000  | 0.0           |
| 0.5941 | 4500  | 0.0           |
| 0.6602 | 5000  | 0.0           |
| 0.7262 | 5500  | 0.0002        |
| 0.7922 | 6000  | 0.0           |
| 0.8582 | 6500  | 0.0           |
| 0.9242 | 7000  | 0.0           |
| 0.9902 | 7500  | 0.0           |
| 1.0562 | 8000  | 0.0002        |
| 1.1223 | 8500  | 0.0           |
| 1.1883 | 9000  | 0.0           |
| 1.2543 | 9500  | 0.0           |
| 1.3203 | 10000 | 0.0           |
| 1.3863 | 10500 | 0.0           |
| 1.4523 | 11000 | 0.0           |
| 1.5184 | 11500 | 0.0           |
| 1.5844 | 12000 | 0.0           |
| 1.6504 | 12500 | 0.0           |
| 1.7164 | 13000 | 0.0002        |
| 1.7824 | 13500 | 0.0           |
| 1.8484 | 14000 | 0.0           |
| 1.9144 | 14500 | 0.0           |
| 1.9805 | 15000 | 0.0           |
| 2.0465 | 15500 | 0.0002        |
| 2.1125 | 16000 | 0.0           |
| 2.1785 | 16500 | 0.0           |
| 2.2445 | 17000 | 0.0           |
| 2.3105 | 17500 | 0.0           |
| 2.3766 | 18000 | 0.0           |
| 2.4426 | 18500 | 0.0           |
| 2.5086 | 19000 | 0.0           |
| 2.5746 | 19500 | 0.0           |
| 2.6406 | 20000 | 0.0           |
| 2.7066 | 20500 | 0.0002        |
| 2.7726 | 21000 | 0.0           |
| 2.8387 | 21500 | 0.0           |
| 2.9047 | 22000 | 0.0           |
| 2.9707 | 22500 | 0.0           |
| 3.0367 | 23000 | 0.0002        |
| 3.1027 | 23500 | 0.0           |
| 3.1687 | 24000 | 0.0           |
| 3.2348 | 24500 | 0.0           |
| 3.3008 | 25000 | 0.0           |
| 3.3668 | 25500 | 0.0           |
| 3.4328 | 26000 | 0.0           |
| 3.4988 | 26500 | 0.0           |
| 3.5648 | 27000 | 0.0           |
| 3.6308 | 27500 | 0.0           |
| 3.6969 | 28000 | 0.0001        |
| 3.7629 | 28500 | 0.0           |
| 3.8289 | 29000 | 0.0           |
| 3.8949 | 29500 | 0.0           |
| 3.9609 | 30000 | 0.0           |


### Framework Versions
- Python: 3.10.12
- Sentence Transformers: 3.3.1
- Transformers: 4.46.2
- PyTorch: 2.5.1+cu121
- Accelerate: 1.1.1
- Datasets: 3.1.0
- Tokenizers: 0.20.3

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

#### MultipleNegativesRankingLoss
```bibtex
@misc{henderson2017efficient,
    title={Efficient Natural Language Response Suggestion for Smart Reply},
    author={Matthew Henderson and Rami Al-Rfou and Brian Strope and Yun-hsuan Sung and Laszlo Lukacs and Ruiqi Guo and Sanjiv Kumar and Balint Miklos and Ray Kurzweil},
    year={2017},
    eprint={1705.00652},
    archivePrefix={arXiv},
    primaryClass={cs.CL}
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->